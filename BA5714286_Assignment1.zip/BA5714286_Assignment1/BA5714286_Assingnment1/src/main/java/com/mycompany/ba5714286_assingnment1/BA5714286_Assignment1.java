/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.ba5714286_assingnment1;

/**
 *
 * @author clxud
 */
public class BA5714286_Assignment1 {

    public static void main(String[] args) {
    Stock stock = new Stock("ORCL", "Oracle Corporation");
        
        stock.setPreviousClosingPrice(34.5);
        stock.setCurrentPrice(34.35);

        System.out.println(stock);
        
        System.out.println("Price change percentage:" + String.format("%.2f", stock.getChangePercent()));
        
        System.out.println("\n");
               
        Person person = new Person("Meow Kittyson","Milktown","420-1738","meowkittyson@gmail.com");
        
        Student student = new Student("Woof Puppyton","Boneville","670-6767","woofpuppyton@hotmail.com",Student.FRESHMAN);
        
        Employee employee = new Employee("Hop Bunnilla","Carrotown","900-7580","hopperstyle@outlook.com","Carrot Office",3000,"03/06/2007");
        
        Faculty faculty = new Faculty("Huff Bearington","Berry Crescent","123-4567","bearcuddles@icloud.com","Berry Office",5200,"09/12/2009","10AM to 12PM","Teacher");
        
        Staff staff = new Staff("Rawr Lionsgate", "MeatieLand","177-0130","huntereyes@aol.com","Scary Office",9000,"25/01/2004","Registrar");
        
        
        System.out.println(person.toString());
        System.out.println(student.toString());
        System.out.println(employee.toString());
        System.out.println(faculty.toString());
        System.out.println(staff.toString());
    } 
}
