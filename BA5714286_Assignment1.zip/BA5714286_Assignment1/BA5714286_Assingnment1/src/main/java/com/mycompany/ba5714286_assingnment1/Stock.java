/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ba5714286_assingnment1;

/**
 *
 * @author clxud
 */
public class Stock {
    
    private String symbol;
    private String name;
    private double previousClosingPrice;
    private double currentPrice;
    
    public Stock(String symbol, String name) {
        this.symbol = symbol;
        this.name = name;
    }
    
    public Stock(Stock other){
        this.symbol = other.symbol;
        this.name = other.name;
        this.previousClosingPrice = other.previousClosingPrice;
        this.currentPrice = other.currentPrice;
    }

    public void setPreviousClosingPrice(double previousClosingPrice) {
        this.previousClosingPrice = previousClosingPrice;
    }

    public void setCurrentPrice(double currentPrice) {
        this.currentPrice = currentPrice;
    }
    
    public double getChangePercent(){
        return ((currentPrice-previousClosingPrice)/previousClosingPrice)*100;
    }

    @Override
    public String toString() {
        return "Stock: { " + "Symbol : " + symbol + 
                "\n         Name : " + name + 
                "\n         Closing Price : " + previousClosingPrice + 
                "\n         Current Price : " + currentPrice + '}';
    }    
}
