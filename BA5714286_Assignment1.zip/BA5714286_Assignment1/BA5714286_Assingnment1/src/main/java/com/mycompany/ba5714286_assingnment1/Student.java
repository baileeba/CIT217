/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ba5714286_assingnment1;

/**
 *
 * @author clxud
 */
public class Student extends Person{
    public static final int FRESHMAN = 1;
    public static final int SOPHMORE = 2;
    public static final int JUNIOR = 3;
    public static final int SENIOR = 3;

    private int status;
    
    public Student(String name, String address, String phoneNumber, String emailAddress, int status) {
        super(name, address, phoneNumber, emailAddress);
        this.status = status;
    }

    @Override
    public String toString() {
        return "Student "+ name;
    }
}
