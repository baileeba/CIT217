/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ba5714286_assignment3;

import java.util.ArrayList;

/**
 *
 * @author clxud
 */
public class Borrower extends User {
    private ArrayList<Item> borrowedItems;
    
    public Borrower(int id, String name){
        super(id, name);
        borrowedItems = new ArrayList<>();
    }

    public ArrayList<Item> getBorrowedItems() {
        return borrowedItems;
    }

    public void setBorrowedItems(ArrayList<Item> borrowedItems) {
        this.borrowedItems = borrowedItems;
    }
    
    public void borrowItem(Item item){
        if (item.isAvailable()){
            borrowedItems.add(item);
            item.setAvailable(false);
            System.out.println("Item borrowed");
        } else {
            System.out.println("item is unavailable");
        }
    }
    
    public void returnItem(Item item){
        if (borrowedItems.contains(item)){
            borrowedItems.remove(item);
            item.setAvailable(true);
            System.out.println("item returned successfully");
        } else {
            System.out.println("item not found in the borrowed list");
        }
    }
    
    public void displayBorrowedItems() {
        if (borrowedItems.isEmpty()){
            System.out.println("no borrowed items");
        }else{
            for (Item item : borrowedItems){
                item.displayInfo();
            }
        }
    }
    
    @Override
    public void displayInfo() {
        System.out.println("borrower ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("borrowed items: ");
        displayBorrowedItems();
    }
}
