/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ba5714286_assignment3;

/**
 *
 * @author clxud
 */
public abstract class Item {
    protected int id;
    protected String title;
    protected boolean isAvailable;
    
    public Item(int id, String title) {
        this.id = id;
        this.title = title;
        this.isAvailable = true;
    }

    //getters n setters

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }
    
    public abstract void displayInfo();
    
}
