/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ba5714286_assignment3;

import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author clxud
 */
public class Library {

    //attributes
    private ArrayList<Item> items = new ArrayList<>();
    private ArrayList<Borrower> borrowers = new ArrayList<>();

    public ArrayList<Item> getItems() {
        return items;
    }

    public ArrayList<Borrower> getBorrowers() {
        return borrowers;
    }
    
    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }

    public void setBorrowers(ArrayList<Borrower> borrowers) {
        this.borrowers = borrowers;
    }

    public void addItem(Item item) {
        items.add(item);
        System.out.println("book added");
    }
    
    public void addUser(Borrower user) {
        borrowers.add(user);
        System.out.println("user added");
    }
    
    public Item searchItem(String title){
        for (Item item : items){
            if (item.getTitle().equalsIgnoreCase(title)){
                return item;
            }
        }
        return null;
    }
    
    public Borrower searchBorrower(String name) {
        for (Borrower b : borrowers) {
            if (b.getName().equalsIgnoreCase(name)) {
                return b;
            }
        }
        return null;
    }
    public static void main(String[] args) {
        Library lib = new Library();
        Scanner sc = new Scanner(System.in);
        int choice;
        
        do {
            System.out.println("MENU");
            System.out.println("1 - Add user");
            System.out.println("2 - Add book");
            System.out.println("3 - Borrow book");
            System.out.println("4 - Return book");
            System.out.println("5 - Search book");
            System.out.println("6 - Search borrower");
            System.out.println("7 - Quit");
            
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); //clear
            
            switch (choice) {
                case 1:
                    System.out.print("Enter user ID: ");
                    int uid = sc.nextInt();
                    sc.nextLine();
                    
                    System.out.print("Enter name: ");
                    String uname = sc.nextLine();
                    
                    lib.addUser(new Borrower(uid, uname));
                    break;
                    
                case 2:
                    System.out.print("Enter book ID: ");
                    int bid = sc.nextInt();
                    sc.nextLine();
                    
                    System.out.print("Enter title: ");
                    String title = sc.nextLine();
                    
                    System.out.print("Enter author: ");
                    String author = sc.nextLine();
                    
                    System.out.print("Enter genre: ");
                    String genre = sc.nextLine();
                    
                    lib.addItem(new Book(bid, title, author, genre));
                    break;
                    
                case 3:
                    System.out.print("Enter borrower name: ");
                    String bname = sc.nextLine();
                    
                    System.out.print("Enter book title: ");
                    String btitle = sc.nextLine();
                    
                    Borrower borrower = lib.searchBorrower(bname);
                    Item item = lib.searchItem(btitle);
                    
                    if (borrower != null && item != null){
                        borrower.borrowItem(item);
                    } else {
                        System.out.println("borrower or book not found");
                    }
                    break;
                    
                case 4:
                    System.out.print("Enter borrower name: ");
                    bname = sc.nextLine();
                    
                    System.out.print("Enter book title: ");
                    btitle = sc.nextLine();
                    
                    borrower = lib.searchBorrower(bname);
                    item = lib.searchItem(btitle);
                    
                    if (borrower != null && item != null) {
                        borrower.returnItem(item);
                    } else {
                        System.out.println("borrower or book not found");
                    }
                    break; 
                
                case 5:
                    System.out.print("Enter book title: ");
                    title = sc.nextLine();
                    
                    Item foundItem = lib.searchItem(title);
                    if (foundItem != null) {
                        foundItem.displayInfo();
                    } else {
                        System.out.println("book not found");
                    }
                    break;
                    
                case 6:
                    System.out.print("Enter borrower name: ");
                    String name = sc.nextLine();
                    
                    Borrower foundBorrower = lib.searchBorrower(name);
                    if (foundBorrower != null) {
                        foundBorrower.displayInfo();
                    } else {
                        System.out.println("borrower not found");
                    }
                    break;
                    
                case 7:
                    System.out.print("Quitting ");
                    break;
                    
                default:
                    System.out.print("invalid input");
            }
            
        } while (choice != 7);
        
        sc.close();
    }
}
