/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ba5714286_assignment3;

/**
 *
 * @author clxud
 */
public abstract class User {
    protected int id;
    protected String name;
    protected String studentId;
    
    public User(int id, String name) {
        this.id = id;
        this.name = name;
    }
    
    public User(String name, String studentId) {
        this.name = name;
        this.studentId = studentId;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
    
    public abstract void displayInfo();
}
