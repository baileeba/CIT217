/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package org.salcc.assignment2;

/**
 *
 * @author clxud
 */
public class Main {

    public static void main(String[] args) {
        Exam finalExam = new Exam("finalexam.pdf","Final",0.78,12,13,8,0);
                
        Assignment lab1 = new Assignment(
                "lab1.pdf","calendar.csv","Lab 1",0.50,8,26,23,59);
                  
        GradedItemList list = new GradedItemList();

        list.addItem(finalExam);
        list.addItem(lab1);

        System.out.println(list);
    }
}
