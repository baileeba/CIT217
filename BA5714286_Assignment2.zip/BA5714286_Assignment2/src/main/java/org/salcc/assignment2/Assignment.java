/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.salcc.assignment2;

/**
 *
 * @author clxud
 */
public class Assignment extends GradedItem{
    //specific attributes to assignments
    private String specification;
    private String data;

    public Assignment(String specification, String data, String name, double grade, int month, int day, int hour, int minute) {
        super(name, grade, month, day, hour, minute);
        //initialise assignment spec attributes
        this.specification = specification;
        this.data = data;
    }

    public String getSpecification() {
        return specification;
    }

    public String getData() {
        return data;
    }
    
    //override toString
    @Override
    public String toString() {
        return super.toString() + " : specification = " + specification +
               " : datasource = " + data;
    }
}