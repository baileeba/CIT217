/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.salcc.assignment2;

import java.util.ArrayList;
/**
 *
 * @author clxud
 */
public class GradedItemList {
    //storing multiple graded items
    private ArrayList<GradedItem> items;
    
    //initialising the ArrayList
    public GradedItemList() {
        items = new ArrayList<>();
    }
    
    //add graded item to list
    public void addItem(GradedItem item) {
        items.add(item);
    }
    
    @Override
    public String toString() {
        String result = "";
        
        //loop through the list
        for (GradedItem item : items) {
            result += item.toString() + "\n";
        }
        
        return result;
    }
}
