/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.salcc.assignment2;

/**
 *
 * @author clxud
 */
public class Exam extends GradedItem{
    
    private String problemSet;

    public Exam(String problemSet, String name, double grade, int month, int day, int hour, int minute) {
        super(name, grade, month, day, hour, minute);
        this.problemSet = problemSet;
    }

    public String getProblemSet() {
        return problemSet;
    }
    
    @Override
    public String toString() {
        return super.toString() + " : problem set = " + problemSet;
    }
}
