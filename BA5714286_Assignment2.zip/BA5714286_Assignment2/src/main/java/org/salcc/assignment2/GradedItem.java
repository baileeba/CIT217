/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.salcc.assignment2;

/**
 *
 * @author clxud
 */
public class GradedItem {
    
    //attributes storing info about graded items
    private String name;
    private double grade;
    private int month;
    private int day;
    private int hour;
    private int minute;
    
    //initialising attributes
    public GradedItem(String name, double grade, int month, int day, int hour, int minute){
        this.name = name;
        this.grade = grade;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
    }
    
    public String getName() {
        return name;
    }

    public double getGrade() {
        return grade;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }
    
    //returning string representing obj
    @Override
    public String toString(){
        return String.format("%s (date: %02d - %02d at %02d:%02d ) : grade = %.2f",
                name, month, day, hour, minute, grade);
    }
}
